"""
docker_manager.py
─────────────────
Manages per-project Docker containers.
Each container = one isolated Python process.
The host Docker socket is bind-mounted so we can spawn sibling containers.

Container lifecycle:
  start  → pull image (cached), create container, inject files + env, run
  stop   → SIGTERM → wait 10s → SIGKILL
  stats  → stream docker stats for CPU/MEM
  logs   → stream container stdout/stderr → Redis pub/sub → WebSocket
"""

import asyncio
import json
import os
import shutil
import uuid
from datetime import datetime
from pathlib import Path

import docker
import docker.errors
import redis.asyncio as aioredis
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update

from config import settings
from database import Process, Log, Project, async_session


# Synchronous docker client (docker SDK is sync; we run blocking calls in thread pool)
_docker_client = docker.from_env()

redis_client: aioredis.Redis = None  # initialized on startup


async def init_redis():
    global redis_client
    redis_client = aioredis.from_url(settings.redis_url, decode_responses=True)


def _project_dir(project_id: str) -> Path:
    p = Path(settings.projects_dir) / project_id
    p.mkdir(parents=True, exist_ok=True)
    return p


def _write_project_files(project_id: str, code: str, requirements: str, main_file: str) -> Path:
    d = _project_dir(project_id)
    (d / main_file).write_text(code)
    if requirements.strip():
        (d / "requirements.txt").write_text(requirements)
    elif (d / "requirements.txt").exists():
        (d / "requirements.txt").unlink()
    return d


async def _append_log(project_id: str, message: str, stream: str = "system"):
    """Persist log line to DB and broadcast via Redis pub/sub."""
    async with async_session() as db:
        db.add(Log(project_id=project_id, message=message, stream=stream, ts=datetime.utcnow()))
        await db.commit()

    if redis_client:
        payload = json.dumps({
            "ts": datetime.utcnow().isoformat(),
            "stream": stream,
            "message": message,
        })
        await redis_client.publish(f"logs:{project_id}", payload)


async def _update_process(project_id: str, **kwargs):
    kwargs["updated_at"] = datetime.utcnow()
    async with async_session() as db:
        result = await db.execute(select(Process).where(Process.project_id == project_id))
        proc = result.scalar_one_or_none()
        if proc is None:
            proc = Process(project_id=project_id, **kwargs)
            db.add(proc)
        else:
            for k, v in kwargs.items():
                setattr(proc, k, v)
        await db.commit()
        return proc


async def _stream_container_logs(container_id: str, project_id: str):
    """Background task: read container stdout/stderr and broadcast."""
    loop = asyncio.get_event_loop()
    try:
        container = await loop.run_in_executor(None, _docker_client.containers.get, container_id)
        log_gen = await loop.run_in_executor(
            None,
            lambda: container.logs(stream=True, follow=True, timestamps=False)
        )
        for chunk in log_gen:
            line = chunk.decode("utf-8", errors="replace").rstrip("\n")
            if line:
                await _append_log(project_id, line, "stdout")
    except Exception as e:
        await _append_log(project_id, f"[Log stream ended: {e}]", "system")


async def _monitor_container(project_id: str, container_id: str, auto_restart: bool, max_restarts: int):
    """Background task: wait for container exit, handle auto-restart."""
    loop = asyncio.get_event_loop()
    while True:
        try:
            container = await loop.run_in_executor(None, _docker_client.containers.get, container_id)
            exit_status = await loop.run_in_executor(None, container.wait)
            exit_code = exit_status.get("StatusCode", -1)

            await _append_log(project_id, f"[Process exited with code {exit_code}]", "system")

            async with async_session() as db:
                result = await db.execute(select(Process).where(Process.project_id == project_id))
                proc = result.scalar_one_or_none()
                if proc is None:
                    return

                # If we were asked to stop cleanly, don't restart
                if proc.status in ("offline", "stopping"):
                    return

                restart_count = proc.restart_count

            if auto_restart and restart_count < max_restarts:
                await _append_log(project_id, f"[Auto-restarting... attempt {restart_count + 1}/{max_restarts}]", "system")
                await asyncio.sleep(3)
                # fetch project for latest code
                async with async_session() as db:
                    result = await db.execute(select(Project).where(Project.id == project_id))
                    proj = result.scalar_one_or_none()
                if proj:
                    await start_project(project_id, proj.code, proj.requirements, proj.main_file, proj.env_vars, auto_restart, max_restarts, restart_count + 1)
                return
            else:
                await _update_process(project_id, status="error" if exit_code != 0 else "offline", stopped_at=datetime.utcnow(), container_id=None)
                return

        except docker.errors.NotFound:
            await _update_process(project_id, status="offline", stopped_at=datetime.utcnow(), container_id=None)
            return
        except Exception as e:
            await _append_log(project_id, f"[Monitor error: {e}]", "system")
            await asyncio.sleep(5)


async def start_project(
    project_id: str,
    code: str,
    requirements: str,
    main_file: str,
    env_vars: dict,
    auto_restart: bool,
    max_restarts: int,
    restart_count: int = 0
):
    loop = asyncio.get_event_loop()

    await _update_process(project_id, status="starting", started_at=datetime.utcnow(), restart_count=restart_count)
    await _append_log(project_id, "[SYSTEM] Writing project files...", "system")

    project_dir = await loop.run_in_executor(
        None, _write_project_files, project_id, code, requirements, main_file
    )

    # Build env dict — mask secret values from logs
    env_dict = {str(k): str(v) for k, v in (env_vars or {}).items()}
    env_dict["MAIN_FILE"] = main_file
    env_dict["PROJECT_DIR"] = "/workspace/project"

    await _append_log(project_id, "[SYSTEM] Starting container...", "system")

    try:
        container = await loop.run_in_executor(
            None,
            lambda: _docker_client.containers.run(
                image=settings.sandbox_image,
                detach=True,
                remove=False,
                name=f"pycloud-{project_id[:8]}-{uuid.uuid4().hex[:6]}",
                volumes={
                    str(project_dir): {"bind": "/workspace/project", "mode": "rw"}
                },
                environment=env_dict,
                mem_limit=settings.container_mem_limit,
                nano_cpus=int(settings.container_cpu_limit * 1e9),
                network_mode="bridge",
                user="sandbox",
                read_only=False,
                cap_drop=["ALL"],
                security_opt=["no-new-privileges"],
            )
        )
    except Exception as e:
        await _update_process(project_id, status="error")
        await _append_log(project_id, f"[SYSTEM][ERROR] Failed to start container: {e}", "system")
        raise

    container_id = container.id
    await _update_process(project_id, status="online", container_id=container_id, restart_count=restart_count)
    await _append_log(project_id, f"[SYSTEM] Container started: {container_id[:12]}", "system")

    # Fire-and-forget background tasks
    asyncio.create_task(_stream_container_logs(container_id, project_id))
    asyncio.create_task(_monitor_container(project_id, container_id, auto_restart, max_restarts))
    asyncio.create_task(_stats_loop(project_id, container_id))


async def stop_project(project_id: str):
    loop = asyncio.get_event_loop()
    async with async_session() as db:
        result = await db.execute(select(Process).where(Process.project_id == project_id))
        proc = result.scalar_one_or_none()

    if proc is None or not proc.container_id:
        await _update_process(project_id, status="offline")
        return

    container_id = proc.container_id
    await _update_process(project_id, status="stopping")
    await _append_log(project_id, "[SYSTEM] Stopping container...", "system")

    try:
        container = await loop.run_in_executor(None, _docker_client.containers.get, container_id)
        await loop.run_in_executor(None, lambda: container.stop(timeout=10))
        await loop.run_in_executor(None, container.remove)
    except docker.errors.NotFound:
        pass
    except Exception as e:
        await _append_log(project_id, f"[SYSTEM][WARN] Error stopping container: {e}", "system")

    await _update_process(project_id, status="offline", stopped_at=datetime.utcnow(), container_id=None)
    await _append_log(project_id, "[SYSTEM] Process stopped.", "system")


async def _stats_loop(project_id: str, container_id: str):
    """Poll container stats every 5s, update DB."""
    loop = asyncio.get_event_loop()
    while True:
        try:
            container = await loop.run_in_executor(None, _docker_client.containers.get, container_id)
            stats = await loop.run_in_executor(
                None, lambda: container.stats(stream=False)
            )
            cpu_delta = stats["cpu_stats"]["cpu_usage"]["total_usage"] - stats["precpu_stats"]["cpu_usage"]["total_usage"]
            system_delta = stats["cpu_stats"]["system_cpu_usage"] - stats["precpu_stats"].get("system_cpu_usage", 0)
            num_cpus = stats["cpu_stats"].get("online_cpus", 1)
            cpu_pct = (cpu_delta / system_delta) * num_cpus * 100 if system_delta > 0 else 0

            mem_usage = stats["memory_stats"].get("usage", 0)
            mem_mb = mem_usage / (1024 * 1024)

            await _update_process(project_id, cpu_percent=round(cpu_pct, 2), mem_mb=round(mem_mb, 2))

            if redis_client:
                await redis_client.publish(f"stats:{project_id}", json.dumps({
                    "cpu": round(cpu_pct, 2),
                    "mem": round(mem_mb, 2),
                }))

        except docker.errors.NotFound:
            break
        except Exception:
            pass

        await asyncio.sleep(5)
