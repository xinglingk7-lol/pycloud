from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    database_url: str = "postgresql+asyncpg://pycloud:pycloud_secret@localhost:5432/pycloud"
    redis_url: str = "redis://localhost:6379"
    secret_key: str = "changeme_in_production"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 60 * 24 * 7  # 7 days

    docker_host: str = "unix:///var/run/docker.sock"
    sandbox_image: str = "pycloud-sandbox"
    max_containers_per_user: int = 3
    container_cpu_limit: float = 0.5
    container_mem_limit: str = "256m"

    projects_dir: str = "/app/projects"

    class Config:
        env_file = ".env"

settings = Settings()
