"""
main.py — PyCloud Backend
FastAPI + WebSocket + Docker orchestration
"""

import asyncio
import json
import uuid
from datetime import datetime
from typing import Optional

import redis.asyncio as aioredis
from fastapi import FastAPI, Depends, HTTPException, WebSocket, WebSocketDisconnect, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel, EmailStr
from sqlalchemy import select, delete
from sqlalchemy.ext.asyncio import AsyncSession

from auth import get_current_user, hash_password, verify_password, create_access_token
from config import settings
from database import get_db, User, Project, Process, Log, engine, Base
import docker_manager

app = FastAPI(title="PyCloud API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── Startup ─────────────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup():
    # Create tables
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    # Init Redis
    await docker_manager.init_redis()


# ─── Schemas ──────────────────────────────────────────────────────────────────

class RegisterRequest(BaseModel):
    email: str
    username: str
    password: str

class ProjectCreate(BaseModel):
    name: str
    description: str = ""

class ProjectUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    code: Optional[str] = None
    requirements: Optional[str] = None
    main_file: Optional[str] = None
    env_vars: Optional[dict] = None
    auto_restart: Optional[bool] = None
    max_restarts: Optional[int] = None


# ─── Auth ─────────────────────────────────────────────────────────────────────

@app.post("/api/auth/register")
async def register(req: RegisterRequest, db: AsyncSession = Depends(get_db)):
    existing = await db.execute(
        select(User).where((User.email == req.email) | (User.username == req.username))
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Email or username already taken")

    user = User(
        email=req.email,
        username=req.username,
        password_hash=hash_password(req.password)
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)

    token = create_access_token({"sub": str(user.id)})
    return {"access_token": token, "token_type": "bearer", "username": user.username}


@app.post("/api/auth/login")
async def login(form: OAuth2PasswordRequestForm = Depends(), db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(User).where((User.email == form.username) | (User.username == form.username))
    )
    user = result.scalar_one_or_none()
    if not user or not verify_password(form.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = create_access_token({"sub": str(user.id)})
    return {"access_token": token, "token_type": "bearer", "username": user.username}


# ─── Projects ─────────────────────────────────────────────────────────────────

@app.get("/api/projects")
async def list_projects(user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Project).where(Project.user_id == user.id))
    projects = result.scalars().all()
    out = []
    for p in projects:
        proc_res = await db.execute(select(Process).where(Process.project_id == p.id))
        proc = proc_res.scalar_one_or_none()
        out.append(_project_dict(p, proc))
    return out


@app.post("/api/projects", status_code=201)
async def create_project(req: ProjectCreate, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    existing = await db.execute(
        select(Project).where(Project.user_id == user.id, Project.name == req.name)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Project name already exists")

    p = Project(user_id=user.id, name=req.name, description=req.description)
    db.add(p)
    await db.commit()
    await db.refresh(p)
    return _project_dict(p, None)


@app.get("/api/projects/{project_id}")
async def get_project(project_id: str, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    p = await _get_user_project(project_id, user.id, db)
    proc_res = await db.execute(select(Process).where(Process.project_id == p.id))
    proc = proc_res.scalar_one_or_none()
    return _project_dict(p, proc)


@app.patch("/api/projects/{project_id}")
async def update_project(project_id: str, req: ProjectUpdate, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    p = await _get_user_project(project_id, user.id, db)
    for field, value in req.model_dump(exclude_none=True).items():
        setattr(p, field, value)
    p.updated_at = datetime.utcnow()
    await db.commit()
    await db.refresh(p)
    return _project_dict(p, None)


@app.delete("/api/projects/{project_id}", status_code=204)
async def delete_project(project_id: str, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    p = await _get_user_project(project_id, user.id, db)
    # Stop if running
    proc_res = await db.execute(select(Process).where(Process.project_id == p.id))
    proc = proc_res.scalar_one_or_none()
    if proc and proc.status not in ("offline", "error"):
        await docker_manager.stop_project(str(p.id))
    await db.delete(p)
    await db.commit()


# ─── Process control ─────────────────────────────────────────────────────────

@app.post("/api/projects/{project_id}/start")
async def start_project(project_id: str, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    p = await _get_user_project(project_id, user.id, db)
    proc_res = await db.execute(select(Process).where(Process.project_id == p.id))
    proc = proc_res.scalar_one_or_none()

    if proc and proc.status in ("online", "starting"):
        raise HTTPException(status_code=409, detail="Process already running")

    if not p.code.strip():
        raise HTTPException(status_code=400, detail="No code to run")

    asyncio.create_task(
        docker_manager.start_project(
            str(p.id), p.code, p.requirements, p.main_file, p.env_vars,
            p.auto_restart, p.max_restarts
        )
    )
    return {"status": "starting"}


@app.post("/api/projects/{project_id}/stop")
async def stop_project(project_id: str, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    p = await _get_user_project(project_id, user.id, db)
    asyncio.create_task(docker_manager.stop_project(str(p.id)))
    return {"status": "stopping"}


@app.post("/api/projects/{project_id}/restart")
async def restart_project(project_id: str, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    p = await _get_user_project(project_id, user.id, db)
    if not p.code.strip():
        raise HTTPException(status_code=400, detail="No code to run")

    async def _do_restart():
        await docker_manager.stop_project(str(p.id))
        await asyncio.sleep(1)
        await docker_manager.start_project(
            str(p.id), p.code, p.requirements, p.main_file, p.env_vars,
            p.auto_restart, p.max_restarts
        )

    asyncio.create_task(_do_restart())
    return {"status": "restarting"}


# ─── Logs ─────────────────────────────────────────────────────────────────────

@app.get("/api/projects/{project_id}/logs")
async def get_logs(project_id: str, limit: int = 200, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    p = await _get_user_project(project_id, user.id, db)
    result = await db.execute(
        select(Log).where(Log.project_id == p.id).order_by(Log.ts.desc()).limit(limit)
    )
    logs = result.scalars().all()
    return [{"ts": l.ts.isoformat(), "stream": l.stream, "message": l.message} for l in reversed(logs)]


@app.delete("/api/projects/{project_id}/logs", status_code=204)
async def clear_logs(project_id: str, user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    p = await _get_user_project(project_id, user.id, db)
    await db.execute(delete(Log).where(Log.project_id == p.id))
    await db.commit()


# ─── WebSocket ────────────────────────────────────────────────────────────────

@app.websocket("/ws/{project_id}")
async def websocket_logs(websocket: WebSocket, project_id: str, token: str):
    """
    WebSocket endpoint — streams real-time logs and stats to the browser.
    Auth via ?token=... query param since WS headers are painful in browsers.
    """
    from auth import get_current_user as _gcu
    from jose import jwt, JWTError

    # Validate token
    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
        user_id = payload.get("sub")
    except JWTError:
        await websocket.close(code=4001)
        return

    await websocket.accept()

    r = aioredis.from_url(settings.redis_url, decode_responses=True)
    pubsub = r.pubsub()
    await pubsub.subscribe(f"logs:{project_id}", f"stats:{project_id}")

    try:
        async for message in pubsub.listen():
            if message["type"] == "message":
                await websocket.send_text(json.dumps({
                    "channel": message["channel"],
                    "data": message["data"]
                }))
    except WebSocketDisconnect:
        pass
    finally:
        await pubsub.unsubscribe()
        await r.aclose()


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _project_dict(p: Project, proc: Optional[Process]) -> dict:
    uptime = None
    if proc and proc.started_at and proc.status == "online":
        uptime = int((datetime.utcnow() - proc.started_at.replace(tzinfo=None)).total_seconds())

    return {
        "id": str(p.id),
        "name": p.name,
        "description": p.description,
        "main_file": p.main_file,
        "requirements": p.requirements,
        "code": p.code,
        "env_vars": p.env_vars,
        "auto_restart": p.auto_restart,
        "max_restarts": p.max_restarts,
        "created_at": p.created_at.isoformat(),
        "updated_at": p.updated_at.isoformat(),
        "process": {
            "status": proc.status if proc else "offline",
            "container_id": proc.container_id[:12] if proc and proc.container_id else None,
            "started_at": proc.started_at.isoformat() if proc and proc.started_at else None,
            "uptime_seconds": uptime,
            "cpu_percent": proc.cpu_percent if proc else 0,
            "mem_mb": proc.mem_mb if proc else 0,
            "restart_count": proc.restart_count if proc else 0,
        } if proc else {"status": "offline", "cpu_percent": 0, "mem_mb": 0, "restart_count": 0}
    }


async def _get_user_project(project_id: str, user_id: uuid.UUID, db: AsyncSession) -> Project:
    try:
        pid = uuid.UUID(project_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="Project not found")
    result = await db.execute(
        select(Project).where(Project.id == pid, Project.user_id == user_id)
    )
    p = result.scalar_one_or_none()
    if not p:
        raise HTTPException(status_code=404, detail="Project not found")
    return p
