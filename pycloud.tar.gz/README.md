# PyCloud — Python Cloud Hosting Terminal

Run Python bots and scripts on a remote server. Your code keeps executing even after you close your browser, lock your phone, or lose internet.

```
┌─────────────────────────────────────┐
│  PyCloud Terminal                   │
│  ┌─────────────────────────────┐   │
│  │ [12:30:01] Starting...      │   │
│  │ [12:30:03] Installing deps  │   │
│  │ [12:30:05] Bot connected ✓  │   │
│  └─────────────────────────────┘   │
│  🟢 ONLINE  │ CPU 3%  │ RAM 82MB   │
│  [ START ]  [ STOP ]  [ RESTART ]  │
└─────────────────────────────────────┘
```

---

## Architecture

```
Browser (frontend)
     ↓ HTTP / WebSocket
FastAPI backend  ←→  Redis (pub/sub for logs)
     ↓                    ↓
Docker API          PostgreSQL (state + log history)
     ↓
Sandbox container (pycloud-sandbox)
     └── Python process (your bot/script)
```

The sandbox container keeps running independently of the browser session. The backend streams stdout/stderr via Redis → WebSocket to whoever is currently connected.

---

## Requirements

- Docker 24+
- Docker Compose v2
- ~1 GB RAM free on the server
- Ports 3000 (frontend) and 8000 (backend) available

---

## Installation

### 1. Clone / download the project

```bash
git clone <repo_url>
cd pycloud
```

### 2. Set up environment variables

```bash
cp .env.example .env
```

Edit `.env` and at minimum change:

```
POSTGRES_PASSWORD=your_strong_password
SECRET_KEY=<run: python -c "import secrets; print(secrets.token_hex(32))">
```

If you're hosting on a server (not localhost), also change:

```
NEXT_PUBLIC_API_URL=http://YOUR_SERVER_IP:8000
NEXT_PUBLIC_WS_URL=ws://YOUR_SERVER_IP:8000
```

### 3. Build and start

```bash
chmod +x build.sh
./build.sh
```

This will:
1. Build the `pycloud-sandbox` Docker image (the isolated Python runtime)
2. Build and start all services (frontend, backend, postgres, redis)

That's it.

### 4. Access the site

Open your browser: **http://localhost:3000**

If on a remote server: **http://YOUR_SERVER_IP:3000**

---

## How to use

### Create an account

1. Go to the site → click **Register**
2. Enter email, username, password → Create account

### Create a project

1. Click **New project**
2. Give it a name (e.g. `my-discord-bot`)
3. You're taken to the project dashboard

### Add your Python code

1. In the **Editor** tab, paste your Python code
2. In the `requirements.txt` box, add your dependencies (one per line)

Example for a Discord bot:
```
discord.py
python-dotenv
aiohttp
```

### Add environment variables (tokens, secrets)

1. Go to the **Settings** tab
2. Click **Add** under Environment Variables
3. Add:
   ```
   DISCORD_TOKEN = your_actual_token_here
   ```
4. Token values are masked in the UI and never shown in logs

### Start your bot

1. Click **START**
2. The editor is saved automatically
3. Switch to the **Terminal** tab to watch logs in real time

### Close your browser

Your bot keeps running on the server. Come back any time — the terminal reconnects and shows the current status.

### Stop the bot

Click **STOP** — sends SIGTERM, waits 10 seconds, then SIGKILL if needed.

### Update your code

1. Edit the code in the Editor tab
2. Click **RESTART** — saves the new code, stops the old container, starts a new one with the update

### Auto-restart on crash

In the **Settings** tab, enable **Auto-restart on crash**. Set a max restart count to prevent infinite loops on broken configs.

---

## Discord.py Example

```python
import discord
import os

intents = discord.Intents.default()
intents.message_content = True
client = discord.Client(intents=intents)

@client.event
async def on_ready():
    print(f"Logged in as {client.user}")

@client.event
async def on_message(message):
    if message.author == client.user:
        return
    if message.content == "!ping":
        await message.channel.send("Pong!")

client.run(os.getenv("DISCORD_TOKEN"))
```

`requirements.txt`:
```
discord.py
```

Environment variable in Settings:
```
DISCORD_TOKEN = your_bot_token
```

---

## Managing the server

```bash
# View all logs
docker compose logs -f

# View just the backend
docker compose logs -f backend

# Restart a service
docker compose restart backend

# Stop everything
docker compose down

# Stop and delete all data (WARNING: deletes database)
docker compose down -v

# Check running containers
docker ps
```

---

## Security notes

- Each project runs in its own Docker container with:
  - CPU limited to 0.5 cores (`CONTAINER_CPU_LIMIT`)
  - RAM limited to 256 MB (`CONTAINER_MEM_LIMIT`)
  - All Linux capabilities dropped (`cap_drop: ALL`)
  - No new privileges (`no-new-privileges`)
  - Runs as non-root user `sandbox`
- Tokens and secrets are stored in the database and injected as environment variables — never logged or sent to the frontend
- Each user can only see their own projects
- JWT auth with 7-day expiry

---

## Troubleshooting

**Container fails to start:**
Make sure the sandbox image is built: `docker build -t pycloud-sandbox ./docker/sandbox`

**WebSocket not connecting:**
Check that `NEXT_PUBLIC_WS_URL` in `.env` is correct and uses `ws://` (not `http://`). On HTTPS deployments, use `wss://`.

**Can't install dependencies:**
The sandbox container has common packages pre-installed. For others, add them to `requirements.txt` — they'll be installed inside the container before your code runs.

**Process shows ONLINE but bot isn't responding:**
Check the Terminal tab for Python errors. The most common cause is a missing or wrong `DISCORD_TOKEN` in environment variables.
