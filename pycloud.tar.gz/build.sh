#!/bin/bash
set -e

echo "==> Building PyCloud Sandbox image..."
docker build -t pycloud-sandbox ./docker/sandbox

echo "==> Sandbox image built successfully."
echo "==> Starting all services..."
docker compose up -d --build

echo ""
echo "✓ PyCloud is starting up!"
echo "  Frontend: http://localhost:3000"
echo "  Backend API: http://localhost:8000"
echo "  API docs: http://localhost:8000/docs"
echo ""
echo "  Run 'docker compose logs -f' to watch logs."
