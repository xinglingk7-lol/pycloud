#!/bin/bash
# PyCloud Sandbox entrypoint
# Env vars injected by the backend:
#   MAIN_FILE      — e.g. main.py
#   PROJECT_DIR    — /workspace/project

set -e
cd "${PROJECT_DIR:-/workspace/project}"

echo "[SYSTEM] Container started at $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "[SYSTEM] Python $(python --version)"

# Install user-specified requirements if present
if [ -f "requirements.txt" ]; then
    echo "[SYSTEM] Installing dependencies from requirements.txt..."
    pip install --no-cache-dir -r requirements.txt 2>&1 || {
        echo "[SYSTEM][ERROR] Dependency installation failed"
        exit 1
    }
    echo "[SYSTEM] Dependencies installed."
fi

echo "[SYSTEM] Starting ${MAIN_FILE:-main.py}..."
exec python -u "${MAIN_FILE:-main.py}"
