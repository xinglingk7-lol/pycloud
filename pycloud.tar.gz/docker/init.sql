-- PyCloud database schema

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email TEXT UNIQUE NOT NULL,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS projects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    main_file TEXT DEFAULT 'main.py',
    requirements TEXT DEFAULT '',
    code TEXT DEFAULT '',
    env_vars JSONB DEFAULT '{}',
    auto_restart BOOLEAN DEFAULT FALSE,
    restart_count INTEGER DEFAULT 0,
    max_restarts INTEGER DEFAULT 5,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, name)
);

CREATE TABLE IF NOT EXISTS processes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    container_id TEXT,
    status TEXT DEFAULT 'offline',  -- offline, starting, online, restarting, error, stopping
    pid INTEGER,
    started_at TIMESTAMPTZ,
    stopped_at TIMESTAMPTZ,
    uptime_seconds INTEGER DEFAULT 0,
    cpu_percent REAL DEFAULT 0,
    mem_mb REAL DEFAULT 0,
    restart_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS logs (
    id BIGSERIAL PRIMARY KEY,
    project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    ts TIMESTAMPTZ DEFAULT NOW(),
    stream TEXT DEFAULT 'stdout',  -- stdout, stderr, system
    message TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS logs_project_ts ON logs(project_id, ts DESC);
CREATE INDEX IF NOT EXISTS processes_project ON processes(project_id);

-- Trim old logs automatically (keep last 5000 per project)
CREATE OR REPLACE FUNCTION trim_logs() RETURNS TRIGGER AS $$
BEGIN
    DELETE FROM logs
    WHERE project_id = NEW.project_id
      AND id NOT IN (
        SELECT id FROM logs
        WHERE project_id = NEW.project_id
        ORDER BY ts DESC
        LIMIT 5000
      );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trim_logs_trigger
AFTER INSERT ON logs
FOR EACH ROW EXECUTE FUNCTION trim_logs();
