import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        // Terminal phosphor green palette
        phosphor: {
          50: '#f0fdf4',
          100: '#dcfce7',
          400: '#4ade80',
          500: '#22c55e',
          600: '#16a34a',
          dim: '#15803d',
        },
        terminal: {
          bg: '#0a0f0d',
          surface: '#0f1810',
          border: '#1a2e1f',
          muted: '#1e3327',
          text: '#a3e4b5',
          dim: '#4b7a5c',
        },
        status: {
          online: '#22c55e',
          offline: '#6b7280',
          starting: '#eab308',
          error: '#ef4444',
          restarting: '#f97316',
        }
      },
      fontFamily: {
        mono: ['JetBrains Mono', 'Fira Code', 'Cascadia Code', 'monospace'],
      },
      animation: {
        'blink': 'blink 1s step-end infinite',
        'pulse-slow': 'pulse 3s ease-in-out infinite',
      },
      keyframes: {
        blink: {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0' },
        }
      }
    },
  },
  plugins: [],
}

export default config
