'use client'
import { useState, useEffect, useCallback } from 'react'
import { api, setToken, clearToken, getToken } from '@/lib/api'

export function useAuth() {
  const [user, setUser] = useState<{ username: string } | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const stored = typeof window !== 'undefined' ? localStorage.getItem('pycloud_user') : null
    if (stored && getToken()) {
      setUser(JSON.parse(stored))
    }
    setLoading(false)
  }, [])

  const login = useCallback(async (username: string, password: string) => {
    const data = await api.auth.login(username, password)
    setToken(data.access_token)
    const u = { username: data.username }
    localStorage.setItem('pycloud_user', JSON.stringify(u))
    setUser(u)
  }, [])

  const register = useCallback(async (email: string, username: string, password: string) => {
    const data = await api.auth.register(email, username, password)
    setToken(data.access_token)
    const u = { username: data.username }
    localStorage.setItem('pycloud_user', JSON.stringify(u))
    setUser(u)
  }, [])

  const logout = useCallback(() => {
    clearToken()
    setUser(null)
  }, [])

  return { user, loading, login, register, logout }
}
