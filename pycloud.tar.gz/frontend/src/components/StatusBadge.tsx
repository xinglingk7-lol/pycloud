'use client'

type Status = 'online' | 'offline' | 'starting' | 'stopping' | 'restarting' | 'error'

const STATUS_CONFIG: Record<Status, { label: string; color: string; dot: string; icon: string }> = {
  online:      { label: 'ONLINE',      color: 'text-green-400',  dot: 'bg-green-400 status-online', icon: '●' },
  offline:     { label: 'OFFLINE',     color: 'text-gray-500',   dot: 'bg-gray-500',                icon: '○' },
  starting:    { label: 'STARTING',    color: 'text-yellow-400', dot: 'bg-yellow-400 animate-pulse',icon: '◐' },
  stopping:    { label: 'STOPPING',    color: 'text-orange-400', dot: 'bg-orange-400 animate-pulse',icon: '◑' },
  restarting:  { label: 'RESTARTING', color: 'text-orange-400', dot: 'bg-orange-400 animate-pulse',icon: '↻' },
  error:       { label: 'ERROR',       color: 'text-red-400',    dot: 'bg-red-400',                 icon: '✕' },
}

export default function StatusBadge({ status, large }: { status: string; large?: boolean }) {
  const cfg = STATUS_CONFIG[status as Status] ?? STATUS_CONFIG.offline
  const size = large ? 'text-base gap-2' : 'text-xs gap-1.5'
  const dotSize = large ? 'w-2.5 h-2.5' : 'w-2 h-2'

  return (
    <span className={`inline-flex items-center font-mono font-medium ${size} ${cfg.color}`}>
      <span className={`rounded-full inline-block ${dotSize} ${cfg.dot}`} />
      {cfg.label}
    </span>
  )
}
