'use client'
import { useEffect, useRef, useState, useCallback } from 'react'
import { Copy, Trash2, ChevronDown } from 'lucide-react'

export interface LogLine {
  ts: string
  stream: string
  message: string
}

interface TerminalProps {
  logs: LogLine[]
  onClear?: () => void
  projectName?: string
}

function formatTs(ts: string): string {
  try {
    const d = new Date(ts)
    return d.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })
  } catch {
    return '--:--:--'
  }
}

function lineColor(stream: string, message: string): string {
  if (stream === 'stderr' || message.includes('ERROR') || message.includes('Traceback') || message.includes('Exception')) return 'text-red-400'
  if (message.includes('[SYSTEM]')) return 'text-terminal-dim'
  if (message.includes('WARN') || message.includes('WARNING')) return 'text-yellow-500'
  return 'text-green-300'
}

export default function Terminal({ logs, onClear, projectName }: TerminalProps) {
  const bottomRef = useRef<HTMLDivElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [autoScroll, setAutoScroll] = useState(true)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    if (autoScroll) {
      bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
    }
  }, [logs, autoScroll])

  const handleScroll = useCallback(() => {
    const el = containerRef.current
    if (!el) return
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 40
    setAutoScroll(atBottom)
  }, [])

  const scrollToBottom = () => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
    setAutoScroll(true)
  }

  const copyLogs = () => {
    const text = logs.map(l => `[${formatTs(l.ts)}] ${l.message}`).join('\n')
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  return (
    <div className="flex flex-col h-full bg-terminal-bg border border-terminal-border rounded-lg overflow-hidden">
      {/* Header bar */}
      <div className="flex items-center justify-between px-3 py-2 bg-terminal-surface border-b border-terminal-border shrink-0">
        <div className="flex items-center gap-2">
          <div className="flex gap-1.5">
            <span className="w-3 h-3 rounded-full bg-red-500/60" />
            <span className="w-3 h-3 rounded-full bg-yellow-500/60" />
            <span className="w-3 h-3 rounded-full bg-green-500/60" />
          </div>
          <span className="text-xs text-terminal-dim font-mono ml-1">
            {projectName ? `${projectName} — terminal` : 'terminal'}
          </span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={copyLogs}
            className="flex items-center gap-1 px-2 py-1 text-xs text-terminal-dim hover:text-green-400 transition-colors rounded"
          >
            <Copy size={12} />
            {copied ? 'copied' : 'copy'}
          </button>
          {onClear && (
            <button
              onClick={onClear}
              className="flex items-center gap-1 px-2 py-1 text-xs text-terminal-dim hover:text-red-400 transition-colors rounded"
            >
              <Trash2 size={12} />
              clear
            </button>
          )}
        </div>
      </div>

      {/* Log area */}
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto p-3 font-mono text-xs leading-5 space-y-0.5"
        style={{ minHeight: 0 }}
      >
        {logs.length === 0 ? (
          <div className="text-terminal-dim text-center mt-8 select-none">
            <div className="text-2xl mb-2">▊</div>
            <div>No output yet. Start your project to see logs here.</div>
          </div>
        ) : (
          logs.map((line, i) => (
            <div key={i} className={`flex gap-2 items-start group hover:bg-terminal-surface/40 -mx-1 px-1 rounded ${lineColor(line.stream, line.message)}`}>
              <span className="text-terminal-dim shrink-0 select-none">[{formatTs(line.ts)}]</span>
              <span className="break-all whitespace-pre-wrap">{line.message}</span>
            </div>
          ))
        )}
        <div ref={bottomRef} />
        {/* Blinking cursor */}
        {logs.length > 0 && <div className="cursor text-xs text-green-400 select-none h-4" />}
      </div>

      {/* Scroll to bottom button */}
      {!autoScroll && (
        <button
          onClick={scrollToBottom}
          className="absolute bottom-16 right-4 bg-green-500/20 border border-green-500/40 text-green-400 rounded-full p-1.5 hover:bg-green-500/30 transition-colors"
        >
          <ChevronDown size={16} />
        </button>
      )}
    </div>
  )
}
