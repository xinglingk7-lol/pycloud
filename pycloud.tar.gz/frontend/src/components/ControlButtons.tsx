'use client'
import { Play, Square, RotateCcw, Loader2 } from 'lucide-react'

interface Props {
  status: string
  onStart: () => void
  onStop: () => void
  onRestart: () => void
  loading?: boolean
}

export default function ControlButtons({ status, onStart, onStop, onRestart, loading }: Props) {
  const busy = loading || ['starting', 'stopping', 'restarting'].includes(status)
  const isRunning = ['online', 'starting', 'restarting'].includes(status)

  const btnBase = 'flex items-center justify-center gap-2 px-4 py-3 rounded-lg font-mono font-semibold text-sm transition-all active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed select-none flex-1 min-w-0'

  return (
    <div className="flex gap-2">
      <button
        onClick={onStart}
        disabled={busy || isRunning}
        className={`${btnBase} bg-green-500/15 border border-green-500/40 text-green-400 hover:bg-green-500/25 hover:border-green-500/60`}
      >
        {busy && status === 'starting' ? <Loader2 size={16} className="animate-spin" /> : <Play size={16} />}
        <span>START</span>
      </button>

      <button
        onClick={onStop}
        disabled={busy || !isRunning}
        className={`${btnBase} bg-red-500/15 border border-red-500/40 text-red-400 hover:bg-red-500/25 hover:border-red-500/60`}
      >
        {busy && status === 'stopping' ? <Loader2 size={16} className="animate-spin" /> : <Square size={16} />}
        <span>STOP</span>
      </button>

      <button
        onClick={onRestart}
        disabled={busy || status === 'offline'}
        className={`${btnBase} bg-orange-500/15 border border-orange-500/40 text-orange-400 hover:bg-orange-500/25 hover:border-orange-500/60`}
      >
        {busy && status === 'restarting' ? <Loader2 size={16} className="animate-spin" /> : <RotateCcw size={16} />}
        <span>RESTART</span>
      </button>
    </div>
  )
}
