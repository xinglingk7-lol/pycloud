'use client'
import { useState } from 'react'
import { Plus, Trash2, Eye, EyeOff } from 'lucide-react'

interface Props {
  vars: Record<string, string>
  onChange: (vars: Record<string, string>) => void
}

export default function EnvVarsEditor({ vars, onChange }: Props) {
  const [revealed, setRevealed] = useState<Set<string>>(new Set())

  const entries = Object.entries(vars)

  const add = () => {
    onChange({ ...vars, '': '' })
  }

  const remove = (key: string) => {
    const next = { ...vars }
    delete next[key]
    onChange(next)
  }

  const updateKey = (oldKey: string, newKey: string) => {
    const next: Record<string, string> = {}
    for (const [k, v] of Object.entries(vars)) {
      next[k === oldKey ? newKey : k] = v
    }
    onChange(next)
  }

  const updateVal = (key: string, val: string) => {
    onChange({ ...vars, [key]: val })
  }

  const toggleReveal = (key: string) => {
    setRevealed(prev => {
      const next = new Set(prev)
      next.has(key) ? next.delete(key) : next.add(key)
      return next
    })
  }

  const isSecret = (key: string) => /TOKEN|SECRET|KEY|PASSWORD|PASS|API/i.test(key)

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-terminal-dim uppercase tracking-wider">🔐 Environment Variables</span>
        <button
          onClick={add}
          className="flex items-center gap-1 px-2 py-1 text-xs text-green-400 hover:bg-green-500/10 border border-green-500/30 rounded transition-colors"
        >
          <Plus size={12} />
          Add
        </button>
      </div>

      {entries.length === 0 && (
        <div className="text-xs text-terminal-dim text-center py-3 border border-dashed border-terminal-border rounded-lg">
          No variables. Add your DISCORD_TOKEN and other secrets here.
        </div>
      )}

      <div className="space-y-1.5">
        {entries.map(([key, val], i) => (
          <div key={i} className="flex items-center gap-1.5 bg-terminal-surface border border-terminal-border rounded-lg px-2 py-1.5">
            <input
              value={key}
              onChange={e => updateKey(key, e.target.value)}
              placeholder="VAR_NAME"
              className="w-36 shrink-0 bg-transparent text-xs font-mono text-yellow-300 outline-none placeholder:text-terminal-dim"
            />
            <span className="text-terminal-dim text-xs shrink-0">=</span>
            <input
              value={val}
              onChange={e => updateVal(key, e.target.value)}
              type={isSecret(key) && !revealed.has(key) ? 'password' : 'text'}
              placeholder="value"
              className="flex-1 min-w-0 bg-transparent text-xs font-mono text-green-300 outline-none placeholder:text-terminal-dim"
            />
            {isSecret(key) && (
              <button onClick={() => toggleReveal(key)} className="text-terminal-dim hover:text-green-400 transition-colors shrink-0">
                {revealed.has(key) ? <EyeOff size={12} /> : <Eye size={12} />}
              </button>
            )}
            <button onClick={() => remove(key)} className="text-terminal-dim hover:text-red-400 transition-colors shrink-0">
              <Trash2 size={12} />
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}
