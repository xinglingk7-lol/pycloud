'use client'
import { useEffect, useState } from 'react'

interface ProcessInfo {
  status: string
  container_id?: string
  started_at?: string
  uptime_seconds?: number
  cpu_percent: number
  mem_mb: number
  restart_count: number
}

function formatUptime(seconds?: number): string {
  if (!seconds) return '--'
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = seconds % 60
  if (h > 0) return `${h}h ${m}m`
  if (m > 0) return `${m}m ${s}s`
  return `${s}s`
}

export default function StatsBar({ process: proc, liveStats }: { process?: ProcessInfo; liveStats?: { cpu: number; mem: number } }) {
  const [uptime, setUptime] = useState<number | undefined>(proc?.uptime_seconds)

  useEffect(() => {
    if (proc?.status !== 'online') { setUptime(undefined); return }
    setUptime(proc.uptime_seconds)
    const id = setInterval(() => setUptime(u => (u ?? 0) + 1), 1000)
    return () => clearInterval(id)
  }, [proc?.status, proc?.uptime_seconds])

  const cpu = liveStats?.cpu ?? proc?.cpu_percent ?? 0
  const mem = liveStats?.mem ?? proc?.mem_mb ?? 0

  const stat = (label: string, value: string) => (
    <div className="flex flex-col items-center">
      <span className="text-[10px] text-terminal-dim uppercase tracking-widest">{label}</span>
      <span className="text-xs text-green-300 font-medium">{value}</span>
    </div>
  )

  return (
    <div className="flex items-center justify-around py-2 px-3 bg-terminal-surface border border-terminal-border rounded-lg text-center gap-2">
      {stat('uptime', formatUptime(uptime))}
      <div className="w-px h-6 bg-terminal-border" />
      {stat('cpu', `${cpu.toFixed(1)}%`)}
      <div className="w-px h-6 bg-terminal-border" />
      {stat('ram', `${mem.toFixed(0)} MB`)}
      <div className="w-px h-6 bg-terminal-border" />
      {stat('restarts', String(proc?.restart_count ?? 0))}
      {proc?.container_id && (
        <>
          <div className="w-px h-6 bg-terminal-border" />
          {stat('cid', proc.container_id)}
        </>
      )}
    </div>
  )
}
