'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/hooks/useAuth'
import { api } from '@/lib/api'
import { Plus, LogOut, Terminal, Trash2, Clock } from 'lucide-react'
import StatusBadge from '@/components/StatusBadge'
import { formatDistanceToNow } from 'date-fns'

interface Project {
  id: string
  name: string
  description: string
  created_at: string
  process: { status: string; uptime_seconds?: number; cpu_percent: number; mem_mb: number }
}

export default function Dashboard() {
  const { user, loading, logout } = useAuth()
  const router = useRouter()
  const [projects, setProjects] = useState<Project[]>([])
  const [fetching, setFetching] = useState(true)
  const [newName, setNewName] = useState('')
  const [creating, setCreating] = useState(false)
  const [showCreate, setShowCreate] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (!loading && !user) router.push('/auth')
  }, [user, loading, router])

  useEffect(() => {
    if (!user) return
    api.projects.list().then(setProjects).catch(() => {}).finally(() => setFetching(false))
  }, [user])

  const createProject = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newName.trim()) return
    setCreating(true)
    setError('')
    try {
      const p = await api.projects.create(newName.trim())
      router.push(`/project/${p.id}`)
    } catch (err: unknown) {
      setError((err as Error).message)
      setCreating(false)
    }
  }

  const deleteProject = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation()
    if (!confirm('Delete this project?')) return
    await api.projects.delete(id)
    setProjects(prev => prev.filter(p => p.id !== id))
  }

  if (loading || !user) return null

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b border-terminal-border bg-terminal-surface/60 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Terminal size={18} className="text-green-400" />
            <span className="font-mono text-sm font-semibold text-green-400">PyCloud</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs text-terminal-dim font-mono">~/{user.username}</span>
            <button onClick={() => { logout(); router.push('/auth') }} className="text-terminal-dim hover:text-red-400 transition-colors">
              <LogOut size={15} />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="font-mono text-lg font-semibold text-green-300">Projects</h1>
            <p className="text-xs text-terminal-dim mt-0.5">{projects.length} project{projects.length !== 1 ? 's' : ''}</p>
          </div>
          <button
            onClick={() => setShowCreate(true)}
            className="flex items-center gap-2 px-3 py-2 bg-green-500/15 border border-green-500/40 text-green-400 rounded-lg font-mono text-xs hover:bg-green-500/25 transition-colors"
          >
            <Plus size={14} />
            New project
          </button>
        </div>

        {/* Create modal */}
        {showCreate && (
          <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
            <div className="bg-terminal-surface border border-terminal-border rounded-xl p-6 w-full max-w-sm">
              <h2 className="font-mono text-sm font-semibold text-green-300 mb-4">New Project</h2>
              <form onSubmit={createProject} className="space-y-3">
                <input
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  placeholder="my-discord-bot"
                  autoFocus
                  className="w-full bg-terminal-bg border border-terminal-border rounded-lg px-3 py-2.5 text-sm font-mono text-green-300 placeholder:text-terminal-dim focus:outline-none focus:border-green-500/60"
                />
                {error && <p className="text-xs text-red-400">{error}</p>}
                <div className="flex gap-2">
                  <button type="button" onClick={() => setShowCreate(false)} className="flex-1 py-2 text-xs font-mono text-terminal-dim border border-terminal-border rounded-lg hover:text-green-400 transition-colors">
                    Cancel
                  </button>
                  <button type="submit" disabled={creating} className="flex-1 py-2 text-xs font-mono bg-green-500/20 border border-green-500/40 text-green-400 rounded-lg hover:bg-green-500/30 transition-colors disabled:opacity-50">
                    {creating ? '...' : 'Create →'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Project list */}
        {fetching ? (
          <div className="text-center py-12 text-terminal-dim text-sm font-mono">Loading...</div>
        ) : projects.length === 0 ? (
          <div className="text-center py-16 border border-dashed border-terminal-border rounded-xl">
            <Terminal size={32} className="text-terminal-dim mx-auto mb-3" />
            <p className="text-sm font-mono text-terminal-dim">No projects yet.</p>
            <p className="text-xs text-terminal-dim mt-1">Create one to start running Python on the server.</p>
          </div>
        ) : (
          <div className="grid gap-3">
            {projects.map(p => (
              <div
                key={p.id}
                onClick={() => router.push(`/project/${p.id}`)}
                className="group bg-terminal-surface border border-terminal-border rounded-xl p-4 cursor-pointer hover:border-green-500/40 hover:bg-terminal-muted transition-all"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <StatusBadge status={p.process.status} />
                    </div>
                    <h3 className="font-mono font-semibold text-green-300 text-sm truncate">{p.name}</h3>
                    {p.description && (
                      <p className="text-xs text-terminal-dim truncate mt-0.5">{p.description}</p>
                    )}
                    <div className="flex items-center gap-3 mt-2">
                      {p.process.status === 'online' && (
                        <>
                          <span className="text-xs text-terminal-dim">CPU {p.process.cpu_percent.toFixed(1)}%</span>
                          <span className="text-xs text-terminal-dim">{p.process.mem_mb.toFixed(0)} MB</span>
                        </>
                      )}
                      <span className="text-xs text-terminal-dim flex items-center gap-1">
                        <Clock size={10} />
                        {formatDistanceToNow(new Date(p.created_at), { addSuffix: true })}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={e => deleteProject(p.id, e)}
                    className="text-terminal-dim hover:text-red-400 transition-colors opacity-0 group-hover:opacity-100 shrink-0 mt-1"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
