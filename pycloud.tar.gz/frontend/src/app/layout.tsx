import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'PyCloud — Python Hosting Terminal',
  description: 'Run Python bots and scripts on a remote server. Keep your code alive even when your phone is off.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="bg-terminal-bg text-terminal-text font-mono antialiased min-h-screen">
        {children}
      </body>
    </html>
  )
}
