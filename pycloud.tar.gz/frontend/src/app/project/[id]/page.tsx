'use client'
import { useEffect, useState, useRef, useCallback } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { useAuth } from '@/hooks/useAuth'
import { api, createWebSocket } from '@/lib/api'
import dynamic from 'next/dynamic'
import { python } from '@codemirror/lang-python'
import { oneDark } from '@codemirror/theme-one-dark'
import { ArrowLeft, Save, Code2, TerminalSquare, Settings2, RefreshCw } from 'lucide-react'

import Terminal, { LogLine } from '@/components/Terminal'
import StatusBadge from '@/components/StatusBadge'
import ControlButtons from '@/components/ControlButtons'
import StatsBar from '@/components/StatsBar'
import EnvVarsEditor from '@/components/EnvVarsEditor'

const CodeMirror = dynamic(() => import('@uiw/react-codemirror'), { ssr: false })

type Tab = 'editor' | 'terminal' | 'settings'

const DEFAULT_CODE = `# Paste your Python code here
# Example: Discord bot

import discord

intents = discord.Intents.default()
intents.message_content = True
client = discord.Client(intents=intents)

@client.event
async def on_ready():
    print(f"Logged in as {client.user}")

@client.event
async def on_message(message):
    if message.author == client.user:
        return
    if message.content.startswith("!ping"):
        await message.channel.send("Pong!")

# Your token should be in the DISCORD_TOKEN env variable
import os
client.run(os.getenv("DISCORD_TOKEN"))
`

export default function ProjectPage() {
  const { id } = useParams() as { id: string }
  const router = useRouter()
  const { user, loading } = useAuth()

  const [project, setProject] = useState<Record<string, unknown> | null>(null)
  const [logs, setLogs] = useState<LogLine[]>([])
  const [tab, setTab] = useState<Tab>('editor')
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [actionLoading, setActionLoading] = useState(false)
  const [liveStats, setLiveStats] = useState<{ cpu: number; mem: number } | undefined>()

  // Local editor state
  const [code, setCode] = useState(DEFAULT_CODE)
  const [requirements, setRequirements] = useState('')
  const [mainFile, setMainFile] = useState('main.py')
  const [envVars, setEnvVars] = useState<Record<string, string>>({})
  const [autoRestart, setAutoRestart] = useState(false)
  const [maxRestarts, setMaxRestarts] = useState(5)

  const wsRef = useRef<WebSocket | null>(null)
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    if (!loading && !user) router.push('/auth')
  }, [user, loading, router])

  // Load project
  useEffect(() => {
    if (!user) return
    api.projects.get(id).then(p => {
      setProject(p)
      setCode(p.code || DEFAULT_CODE)
      setRequirements(p.requirements || '')
      setMainFile(p.main_file || 'main.py')
      setEnvVars(p.env_vars || {})
      setAutoRestart(p.auto_restart || false)
      setMaxRestarts(p.max_restarts || 5)
    }).catch(() => router.push('/'))

    // Load initial logs
    api.projects.getLogs(id).then(setLogs).catch(() => {})
  }, [id, user, router])

  // WebSocket for real-time logs
  useEffect(() => {
    if (!user) return
    const ws = createWebSocket(id)
    wsRef.current = ws

    ws.onmessage = (e) => {
      try {
        const msg = JSON.parse(e.data)
        const channel: string = msg.channel
        const data = JSON.parse(msg.data)

        if (channel.startsWith('logs:')) {
          setLogs(prev => [...prev.slice(-2000), data as LogLine])
        } else if (channel.startsWith('stats:')) {
          setLiveStats(data)
        }
      } catch {}
    }

    ws.onerror = () => {}
    ws.onclose = () => {
      // Reconnect after 3s
      setTimeout(() => {
        if (wsRef.current?.readyState === WebSocket.CLOSED) {
          wsRef.current = createWebSocket(id)
        }
      }, 3000)
    }

    return () => ws.close()
  }, [id, user])

  // Poll project status
  useEffect(() => {
    pollRef.current = setInterval(() => {
      api.projects.get(id).then(p => setProject(p)).catch(() => {})
    }, 5000)
    return () => { if (pollRef.current) clearInterval(pollRef.current) }
  }, [id])

  const saveProject = useCallback(async () => {
    setSaving(true)
    try {
      const updated = await api.projects.update(id, { code, requirements, main_file: mainFile, env_vars: envVars, auto_restart: autoRestart, max_restarts: maxRestarts })
      setProject(updated)
      setSaved(true)
      setTimeout(() => setSaved(false), 2000)
    } finally {
      setSaving(false)
    }
  }, [id, code, requirements, mainFile, envVars, autoRestart, maxRestarts])

  const handleStart = async () => {
    setActionLoading(true)
    // Save first
    await api.projects.update(id, { code, requirements, main_file: mainFile, env_vars: envVars, auto_restart: autoRestart, max_restarts: maxRestarts })
    await api.projects.start(id).catch(() => {})
    setActionLoading(false)
    setTab('terminal')
    setTimeout(() => api.projects.get(id).then(setProject).catch(() => {}), 1000)
  }

  const handleStop = async () => {
    setActionLoading(true)
    await api.projects.stop(id).catch(() => {})
    setActionLoading(false)
    setTimeout(() => api.projects.get(id).then(setProject).catch(() => {}), 1000)
  }

  const handleRestart = async () => {
    setActionLoading(true)
    await api.projects.update(id, { code, requirements, main_file: mainFile, env_vars: envVars, auto_restart: autoRestart, max_restarts: maxRestarts })
    await api.projects.restart(id).catch(() => {})
    setActionLoading(false)
    setTab('terminal')
    setTimeout(() => api.projects.get(id).then(setProject).catch(() => {}), 1000)
  }

  const handleClearLogs = async () => {
    await api.projects.clearLogs(id)
    setLogs([])
  }

  if (!project) return (
    <div className="min-h-screen flex items-center justify-center text-terminal-dim font-mono text-sm">
      Loading...
    </div>
  )

  const proc = (project.process as Record<string, unknown>) || {}
  const status = (proc.status as string) || 'offline'
  const projectName = project.name as string

  const tabBtn = (t: Tab, icon: React.ReactNode, label: string) => (
    <button
      onClick={() => setTab(t)}
      className={`flex items-center gap-1.5 px-3 py-2 text-xs font-mono transition-colors rounded-md ${
        tab === t
          ? 'bg-green-500/15 text-green-400 border border-green-500/30'
          : 'text-terminal-dim hover:text-green-400'
      }`}
    >
      {icon}
      {label}
    </button>
  )

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="border-b border-terminal-border bg-terminal-surface/60 backdrop-blur-sm sticky top-0 z-10 shrink-0">
        <div className="max-w-5xl mx-auto px-3 py-2.5 flex items-center gap-3">
          <button onClick={() => router.push('/')} className="text-terminal-dim hover:text-green-400 transition-colors">
            <ArrowLeft size={16} />
          </button>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="font-mono font-semibold text-green-300 text-sm truncate">{projectName}</span>
              <StatusBadge status={status} />
            </div>
          </div>
          <button
            onClick={saveProject}
            disabled={saving}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-mono bg-terminal-bg border border-terminal-border rounded-lg text-terminal-dim hover:text-green-400 hover:border-green-500/40 transition-colors"
          >
            <Save size={13} />
            {saved ? 'Saved ✓' : saving ? '...' : 'Save'}
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-5xl mx-auto w-full px-3 py-4 flex flex-col gap-4" style={{ minHeight: 0 }}>
        {/* Stats + Controls */}
        <div className="flex flex-col gap-2 shrink-0">
          <StatsBar process={proc as Parameters<typeof StatsBar>[0]['process']} liveStats={liveStats} />
          <ControlButtons
            status={status}
            onStart={handleStart}
            onStop={handleStop}
            onRestart={handleRestart}
            loading={actionLoading}
          />
        </div>

        {/* Tab selector */}
        <div className="flex gap-1 shrink-0 overflow-x-auto pb-0.5">
          {tabBtn('editor', <Code2 size={13} />, 'Editor')}
          {tabBtn('terminal', <TerminalSquare size={13} />, 'Terminal')}
          {tabBtn('settings', <Settings2 size={13} />, 'Settings')}
        </div>

        {/* Tab content */}
        <div className="flex-1 min-h-0" style={{ height: 'calc(100vh - 280px)' }}>
          {tab === 'editor' && (
            <div className="h-full flex flex-col gap-3">
              <div className="flex-1 min-h-0 border border-terminal-border rounded-lg overflow-hidden">
                <CodeMirror
                  value={code}
                  height="100%"
                  theme={oneDark}
                  extensions={[python()]}
                  onChange={setCode}
                  basicSetup={{ lineNumbers: true, foldGutter: true }}
                  style={{ height: '100%' }}
                />
              </div>

              <div className="shrink-0">
                <label className="text-xs text-terminal-dim uppercase tracking-wider block mb-1.5">requirements.txt</label>
                <textarea
                  value={requirements}
                  onChange={e => setRequirements(e.target.value)}
                  placeholder={"discord.py\nrequests\naiohttp"}
                  rows={4}
                  className="w-full bg-terminal-surface border border-terminal-border rounded-lg px-3 py-2 text-xs font-mono text-green-300 placeholder:text-terminal-dim focus:outline-none focus:border-green-500/40 resize-none"
                />
              </div>
            </div>
          )}

          {tab === 'terminal' && (
            <div className="h-full relative">
              <Terminal
                logs={logs}
                onClear={handleClearLogs}
                projectName={projectName}
              />
            </div>
          )}

          {tab === 'settings' && (
            <div className="overflow-y-auto h-full space-y-5 pr-1">
              <div className="space-y-3">
                <div>
                  <label className="text-xs text-terminal-dim uppercase tracking-wider block mb-1.5">Main file</label>
                  <input
                    value={mainFile}
                    onChange={e => setMainFile(e.target.value)}
                    className="w-full bg-terminal-surface border border-terminal-border rounded-lg px-3 py-2 text-sm font-mono text-green-300 focus:outline-none focus:border-green-500/40"
                    placeholder="main.py"
                  />
                </div>
              </div>

              <EnvVarsEditor vars={envVars} onChange={setEnvVars} />

              <div className="space-y-3">
                <label className="text-xs text-terminal-dim uppercase tracking-wider block">Crash recovery</label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <div
                    onClick={() => setAutoRestart(!autoRestart)}
                    className={`w-9 h-5 rounded-full transition-colors cursor-pointer ${autoRestart ? 'bg-green-500' : 'bg-terminal-border'}`}
                  >
                    <div className={`w-4 h-4 rounded-full bg-white m-0.5 transition-transform ${autoRestart ? 'translate-x-4' : ''}`} />
                  </div>
                  <span className="text-xs text-green-300 font-mono">Auto-restart on crash</span>
                </label>
                {autoRestart && (
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-terminal-dim">Max restarts:</span>
                    <input
                      type="number"
                      value={maxRestarts}
                      onChange={e => setMaxRestarts(Number(e.target.value))}
                      min={1} max={20}
                      className="w-16 bg-terminal-surface border border-terminal-border rounded px-2 py-1 text-xs font-mono text-green-300 text-center focus:outline-none"
                    />
                  </div>
                )}
              </div>

              <button
                onClick={saveProject}
                disabled={saving}
                className="w-full py-2.5 bg-green-500/15 border border-green-500/40 text-green-400 rounded-lg font-mono text-xs hover:bg-green-500/25 transition-colors"
              >
                {saved ? '✓ Saved' : saving ? 'Saving...' : 'Save settings'}
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
