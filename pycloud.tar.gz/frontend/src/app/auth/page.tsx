'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/hooks/useAuth'

export default function AuthPage() {
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [email, setEmail] = useState('')
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const { login, register } = useAuth()
  const router = useRouter()

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      if (mode === 'login') {
        await login(username, password)
      } else {
        await register(email, username, password)
      }
      router.push('/')
    } catch (err: unknown) {
      setError((err as Error).message)
    } finally {
      setLoading(false)
    }
  }

  const input = 'w-full bg-terminal-surface border border-terminal-border rounded-lg px-3 py-2.5 text-sm font-mono text-green-300 placeholder:text-terminal-dim focus:outline-none focus:border-green-500/60 transition-colors'
  const label = 'text-xs text-terminal-dim uppercase tracking-wider block mb-1.5'

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* ASCII logo */}
        <div className="text-center mb-8">
          <pre className="text-green-500 text-xs leading-tight select-none">
{`██████╗ ██╗   ██╗ ██████╗██╗      ██████╗ ██╗   ██╗██████╗
██╔══██╗╚██╗ ██╔╝██╔════╝██║     ██╔═══██╗██║   ██║██╔══██╗
██████╔╝ ╚████╔╝ ██║     ██║     ██║   ██║██║   ██║██║  ██║
██╔═══╝   ╚██╔╝  ██║     ██║     ██║   ██║██║   ██║██║  ██║
██║        ██║   ╚██████╗███████╗╚██████╔╝╚██████╔╝██████╔╝
╚═╝        ╚═╝    ╚═════╝╚══════╝ ╚═════╝  ╚═════╝ ╚═════╝`}
          </pre>
          <p className="text-terminal-dim text-xs mt-2">Python hosting. Your bot stays online.</p>
        </div>

        <div className="bg-terminal-surface border border-terminal-border rounded-xl p-6">
          {/* Tab switcher */}
          <div className="flex mb-6 bg-terminal-bg rounded-lg p-0.5">
            {(['login', 'register'] as const).map(m => (
              <button
                key={m}
                onClick={() => { setMode(m); setError('') }}
                className={`flex-1 py-1.5 text-xs font-mono rounded-md transition-all uppercase tracking-wider ${
                  mode === m
                    ? 'bg-green-500/20 text-green-400 border border-green-500/40'
                    : 'text-terminal-dim hover:text-green-400'
                }`}
              >
                {m}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="space-y-4">
            {mode === 'register' && (
              <div>
                <label className={label}>Email</label>
                <input className={input} type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" required />
              </div>
            )}
            <div>
              <label className={label}>Username</label>
              <input className={input} value={username} onChange={e => setUsername(e.target.value)} placeholder="your_username" required />
            </div>
            <div>
              <label className={label}>Password</label>
              <input className={input} type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required />
            </div>

            {error && (
              <div className="text-xs text-red-400 font-mono bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2">
                ✕ {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-green-500/20 border border-green-500/50 text-green-400 rounded-lg font-mono font-semibold text-sm hover:bg-green-500/30 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? '...' : mode === 'login' ? '→ LOGIN' : '→ CREATE ACCOUNT'}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}
