const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

export function getToken(): string | null {
  if (typeof window === 'undefined') return null
  return localStorage.getItem('pycloud_token')
}

export function setToken(token: string) {
  localStorage.setItem('pycloud_token', token)
}

export function clearToken() {
  localStorage.removeItem('pycloud_token')
  localStorage.removeItem('pycloud_user')
}

async function request(path: string, options: RequestInit = {}) {
  const token = getToken()
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(options.headers || {}),
  }

  const res = await fetch(`${API}${path}`, { ...options, headers })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }))
    throw new Error(err.detail || 'Request failed')
  }
  if (res.status === 204) return null
  return res.json()
}

export const api = {
  auth: {
    register: (email: string, username: string, password: string) =>
      request('/api/auth/register', { method: 'POST', body: JSON.stringify({ email, username, password }) }),
    login: (username: string, password: string) => {
      const form = new URLSearchParams()
      form.append('username', username)
      form.append('password', password)
      return fetch(`${API}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: form,
      }).then(r => r.ok ? r.json() : r.json().then(e => { throw new Error(e.detail) }))
    },
  },
  projects: {
    list: () => request('/api/projects'),
    create: (name: string, description?: string) =>
      request('/api/projects', { method: 'POST', body: JSON.stringify({ name, description }) }),
    get: (id: string) => request(`/api/projects/${id}`),
    update: (id: string, data: Record<string, unknown>) =>
      request(`/api/projects/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),
    delete: (id: string) => request(`/api/projects/${id}`, { method: 'DELETE' }),
    start: (id: string) => request(`/api/projects/${id}/start`, { method: 'POST' }),
    stop: (id: string) => request(`/api/projects/${id}/stop`, { method: 'POST' }),
    restart: (id: string) => request(`/api/projects/${id}/restart`, { method: 'POST' }),
    getLogs: (id: string, limit = 200) => request(`/api/projects/${id}/logs?limit=${limit}`),
    clearLogs: (id: string) => request(`/api/projects/${id}/logs`, { method: 'DELETE' }),
  },
}

export function createWebSocket(projectId: string): WebSocket {
  const WS = process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:8000'
  const token = getToken()
  return new WebSocket(`${WS}/ws/${projectId}?token=${token}`)
}
